// src/pages/Plans.jsx
import React from "react";
import { useAuth } from "../context/AuthContext.jsx";

export default function Plans(){
  const { plan, setUserPlan } = useAuth();

  const card = {
    background: "var(--panel)",
    border: "1px solid #1f2937",
    borderRadius: 14,
    padding: 18,
    marginBottom: 16,
  };

  const pill = {
    padding: "4px 8px",
    borderRadius: 999,
    border: "1px solid #374151",
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: ".06em",
  };

  return (
    <main className="container">
      <h2 style={{ marginTop: 0 }}>Plans</h2>
      <p className="meta" style={{ marginBottom: 16 }}>
        Current plan: <span className="badge" style={pill}>{plan.toUpperCase()}</span>
      </p>

      {/* FREE PLAN */}
      <section style={card}>
        <h3 style={{ margin: "0 0 8px" }}>Free</h3>
        <ul className="meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
          <li>Create, view, complete and delete tasks</li>
          <li>Filter by subject, priority and search</li>
          <li><b>Due Date:</b> Not available</li>
        </ul>
        <div style={{ marginTop: 12 }}>
          <button
            className="btn"
            disabled={plan === "free"}
            onClick={() => setUserPlan("free")}
          >
            {plan === "free" ? "Current plan" : "Switch to Free"}
          </button>
        </div>
      </section>

      {/* PRO PLAN */}
      <section style={card}>
        <h3 style={{ margin: "0 0 8px" }}>Pro</h3>
        <ul className="meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
          <li>All the Free Plan features</li>
          <li>Add and view <b>Due Dates</b> on tasks</li>
        </ul>
        <div style={{ marginTop: 12 }}>
          <button
            className="btn primary"
            disabled={plan === "pro"}
            onClick={() => setUserPlan("pro")}
          >
            {plan === "pro" ? "Current plan" : "Activate Pro"}
          </button>
        </div>
      </section>

      <p className="meta">
        The <b>Pro</b> plan enables a <b>Due Date</b> picker when adding tasks
        and shows due dates beside each task.
      </p>
    </main>
  );
}
