import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import AuthProvider from "./context/AuthContext.jsx";
import { TasksProvider } from "./context/TasksContext.jsx";
import ProtectedRoute from "./routes/ProtectedRoute.jsx";
import FocusProvider from "./context/FocusContext.jsx";           
import FocusSetup from "./components/FocusSetup.jsx";             
import FocusHUD from "./components/FocusHUD.jsx";                 

import Home from "./pages/Home.jsx";
import Plans from "./pages/Plans.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import TasksOnly from "./pages/TasksOnly.jsx";
import NotFound from "./pages/NotFound.jsx";
import "./App.css";
import ForgotPassword from "./pages/ForgotPassword.jsx";

export default function App(){
  return (
    <AuthProvider>
      <TasksProvider>
        <FocusProvider>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/plans" element={<ProtectedRoute><Plans /></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><TasksOnly /></ProtectedRoute>} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="*" element={<NotFound />} />
          </Routes>

          {/* Global focus UI */}
          <FocusSetup />
          <FocusHUD />
        </FocusProvider>
      </TasksProvider>
    </AuthProvider>
  );
}
