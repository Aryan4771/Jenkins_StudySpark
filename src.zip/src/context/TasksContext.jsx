// src/context/TasksContext.jsx
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useAuth } from "./AuthContext.jsx";
import { db } from "../firebase";
import {
  collection, addDoc, doc, deleteDoc, updateDoc, onSnapshot, orderBy, query
} from "firebase/firestore";

const TasksContext = createContext();
export function useTasks(){ return useContext(TasksContext); }

export function TasksProvider({ children }){
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [filters, setFilters] = useState({ subject: "All", priority: "All", query: "" });

  // realtime tasks for current user
  useEffect(() => {
    if(!user){ setTasks([]); return; }
    const col = collection(db, "users", user.uid, "tasks");
    const q = query(col, orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const list = [];
      snap.forEach(d => list.push({ id: d.id, ...d.data() }));
      setTasks(list);
    });
    return () => unsub();
  }, [user]);

  // subjects derived from tasks
  const subjects = useMemo(() => {
    const s = new Set();
    tasks.forEach(t => t.subject && s.add(t.subject));
    return Array.from(s).sort();
  }, [tasks]);

  // create a task 
  async function addTask({ title, subject, priority, dueAt }){
    if(!user) return;
    const col = collection(db, "users", user.uid, "tasks");
    await addDoc(col, {
      title: title.trim(),
      subject: subject.trim(),
      priority,
      done: false,
      ...(dueAt ? { dueAt } : {}),
      createdAt: Date.now()
    });
  }

  // toggle done
  async function toggleDone(id, done){
    if(!user) return;
    const ref = doc(db, "users", user.uid, "tasks", id);
    await updateDoc(ref, { done: !done });
  }

  // delete
  async function removeTask(id){
    if(!user) return;
    const ref = doc(db, "users", user.uid, "tasks", id);
    await deleteDoc(ref);
  }

  const value = {
    tasks,
    filters, setFilters,
    addTask, toggleDone, removeTask,
    subjects
  };

  return <TasksContext.Provider value={value}>{children}</TasksContext.Provider>;
}
