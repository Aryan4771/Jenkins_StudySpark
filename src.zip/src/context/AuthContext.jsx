// src/context/AuthContext.jsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { auth, db, googleProvider } from "../firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  browserLocalPersistence,
  setPersistence,
  sendPasswordResetEmail,          
} from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";

const AuthContext = createContext();
export function useAuth(){ return useContext(AuthContext); }

export default function AuthProvider({ children }){
  const [user, setUser] = useState(null);
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setPersistence(auth, browserLocalPersistence).finally(() => {
      const unsub = onAuthStateChanged(auth, async (u) => {
        setUser(u);
        if (u) {
          const ref = doc(db, "users", u.uid);
          const snap = await getDoc(ref);
          if (!snap.exists()) {
            await setDoc(ref, { email: u.email ?? "", plan: "free" }, { merge: true });
            setPlan("free");
          } else {
            setPlan(snap.data().plan ?? "free");
          }
        } else {
          setPlan(null);
        }
        setLoading(false);
      });
      return () => unsub();
    });
  }, []);

  async function signup(email, password){
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    const ref = doc(db, "users", cred.user.uid);
    await setDoc(ref, { email: cred.user.email ?? "", plan: "free" }, { merge: true });
    return cred.user;
  }

  async function login(email, password){
    const { user } = await signInWithEmailAndPassword(auth, email, password);
    return user;
  }

  async function loginWithGoogle(){
    const result = await signInWithPopup(auth, googleProvider);
    const gUser = result.user;
    const ref = doc(db, "users", gUser.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(
        ref,
        { email: gUser.email ?? "", provider: "google", plan: "free" },
        { merge: true }
      );
    }
    return gUser;
  }

  // Password reset
  async function resetPassword(email){
    return sendPasswordResetEmail(auth, email);
  }

  function logout(){
    return signOut(auth);
  }

  async function setUserPlan(newPlan){
    if(!user) return;
    const ref = doc(db, "users", user.uid);
    await setDoc(ref, { plan: newPlan, email: user.email ?? "" }, { merge: true });
    setPlan(newPlan);
  }

  // ResetPassword in context value
  const value = { user, plan, signup, login, loginWithGoogle, resetPassword, logout, setUserPlan };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
