// src/components/FocusHUD.jsx
import React from "react";
import { useFocus } from "../context/FocusContext.jsx";

export default function FocusHUD() {
  const { session, pause, resume, cancel, complete } = useFocus();

  // Always compute using safe fallbacks (no conditional hooks)
  const totalSec = session?.totalSec || 1;
  const remainingSec = session?.remainingSec ?? 0;
  const pct = Math.max(
    0,
    Math.min(100, Math.round(((totalSec - remainingSec) / totalSec) * 100))
  );
  const mm = String(Math.floor(remainingSec / 60)).padStart(2, "0");
  const ss = String(remainingSec % 60).padStart(2, "0");
  const mmss = `${mm}:${ss}`;

  if (!session) return null;

  const barWrap = {
    width: "100%",
    height: 10,
    background: "#1f2937",
    borderRadius: 999,
    overflow: "hidden",
  };
  const bar = { height: "100%", width: `${pct}%`, background: "var(--accent)" };
  const dock = {
    position: "fixed",
    left: 0,
    right: 0,
    bottom: 0,
    background: "#0b1324",
    borderTop: "1px solid #1f2937",
    display: "flex",
    alignItems: "center",
    gap: 16,
    padding: "12px 16px",
    zIndex: 999,
  };

  return (
    <div style={dock}>
      <div style={{ width: "100%", display: "flex", justifyContent: "center" }}>
        <div style={{ maxWidth: 900, width: "100%", display: "flex", gap: 16, alignItems: "center" }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: 6,
              }}
            >
              <div style={{ fontWeight: 700 }}>
                {session.title}{" "}
                {session.subject ? (
                  <span className="meta">• {session.subject}</span>
                ) : null}
              </div>
              <div style={{ fontVariantNumeric: "tabular-nums" }}>{mmss}</div>
            </div>
            <div style={barWrap}>
              <div style={bar} />
            </div>
          </div>

          {session.running ? (
            <button className="btn" onClick={pause}>
              Pause
            </button>
          ) : (
            <button className="btn" onClick={resume}>
              Resume
            </button>
          )}
          <button className="btn danger" onClick={cancel}>
            Cancel
          </button>
          <button className="btn primary" onClick={() => complete(true)}>
            Complete & Mark Done
          </button>
        </div>
      </div>
    </div>
  );
}
