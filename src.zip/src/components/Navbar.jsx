// src/components/Navbar.jsx
import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useFocus } from "../context/FocusContext.jsx";

export default function Navbar() {
  const navigate = useNavigate();
  const { user, logout, plan } = useAuth();
  const { openSetup, session, pause, resume, cancel } = useFocus();

  const baseBtn = {
    padding: "8px 16px",
    borderRadius: "10px",
    fontWeight: "bold",
    cursor: "pointer",
    border: "1px solid #222",
    backgroundColor: "white",
  };

  // simple timer text without hooks
  const remainingSec = session?.remainingSec ?? null;
  const timeText =
    remainingSec != null
      ? `${String(Math.floor(remainingSec / 60)).padStart(2, "0")}:${String(
          remainingSec % 60
        ).padStart(2, "0")}`
      : null;

  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "16px",
        padding: "10px 20px",
        backgroundColor: "#0b1324",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}
    >
      <div
        style={{
          fontWeight: 800,
          fontSize: 20,
          cursor: "pointer",
          color: "#22c55e",
        }}
        onClick={() => navigate("/")}
      >
        StudySpark
      </div>

      <div
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
          flexWrap: "wrap",
        }}
      >
        <button style={baseBtn} onClick={() => navigate("/")}>
          Home
        </button>
        <button style={baseBtn} onClick={() => navigate("/tasks")}>
          Tasks
        </button>
        <button style={baseBtn} onClick={() => navigate("/plans")}>
          Plans
        </button>

        {/* Focus button */}
        <button className="btn focus" onClick={() => openSetup(null)}>
          Focus
        </button>

        {/* If a session is running or paused, show a tiny HUD in navbar */}
        {session && (
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span className="badge" style={{ borderColor: "#374151" }}>
              {session.title || "Focus"} • {timeText}
            </span>
            {session.running ? (
              <button className="btn" onClick={pause} title="Pause">
                Pause
              </button>
            ) : (
              <button className="btn" onClick={resume} title="Resume">
                Resume
              </button>
            )}
            <button className="btn danger" onClick={cancel} title="Cancel">
              ×
            </button>
          </div>
        )}

        {user ? (
          <>
            <span className="badge" style={{ borderColor: "#374151" }}>
              {(plan || "free").toUpperCase()}
            </span>
            <span className="meta">{user.displayName || user.email}</span>
            <button className="btn danger" onClick={logout}>
              Logout
            </button>
          </>
        ) : (
          <>
            <button style={baseBtn} onClick={() => navigate("/login")}>
              Login
            </button>
            <button className="btn primary" onClick={() => navigate("/signup")}>
              Sign up
            </button>
          </>
        )}
      </div>
    </header>
  );
}
