// src/components/TaskItem.jsx
import React from "react";

export default function TaskItem({ task, onToggle, onDelete }) {
  const { id, title, subject, priority, done, dueAt } = task;

  return (
    <div className="task">
      {/* col 1: checkbox */}
      <input
        className="check"
        type="checkbox"
        checked={!!done}
        onChange={() => onToggle(id, done)}
        aria-label="Mark complete"
      />

      {/* col 2: content */}
      <div className="task-content">
        <div className={`task-title ${done ? "done" : ""}`}>{title}</div>
        <div className="task-meta">
          <span className="badge">{subject || "General"}</span>
          <span
            className={`badge ${String(priority || "Medium").toLowerCase()}`}
          >
            {priority || "Medium"}
          </span>
          {dueAt && <span className="badge">Due: {dueAt}</span>}
        </div>
      </div>

      {/* col 3: actions */}
      <div className="task-actions">
        <button className="btn danger" onClick={() => onDelete(id)}>
          Delete
        </button>
      </div>
    </div>
  );
}
